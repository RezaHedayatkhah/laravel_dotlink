@extends('layout')

@section('content')
<div class="d-flex justify-content-center align-items-center vh-100 ">
<h1 class="fs-1 text-info">بزودی</h1>
</div>
@endsection
