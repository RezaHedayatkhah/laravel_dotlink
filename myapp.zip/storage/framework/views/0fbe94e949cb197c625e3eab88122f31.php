<?php $__env->startSection('content'); ?>
    <!-- cards -->
    <div class="cardBox">
        <div class="card">
            <div>
                <div class="numbers"><?php echo e($urlViews); ?></div>
                <div class="cardName">بازدیدها</div>
            </div>
            <div class="iconBx">
                <ion-icon name="eye-outline"></ion-icon>
            </div>
        </div>

        <div class="card">
            <div>
                <div class="numbers"><?php echo e(Auth::user()->withdraw_receipts->sum('amount')); ?></div>
                <div class="cardName">برداشت ها</div>
            </div>
            <div class="iconBx">
                <ion-icon name="receipt-outline"></ion-icon>
            </div>
        </div>

        <div class="card">
            <div>
                <div class="numbers"><?php echo e(Auth::user()->urls->count()); ?></div>
                <div class="cardName">تعداد لینک ها</div>
            </div>
            <div class="iconBx">
                <ion-icon name="link-outline"></ion-icon>
            </div>
        </div>

        <div class="card">
            <div>
                <div class="numbers"><?php echo e(Auth::user()->wallet_balance); ?></div>
                <div class="cardName">درآمد</div>
            </div>
            <div class="iconBx">
                <ion-icon name="cash-outline"></ion-icon>
            </div>
        </div>
    </div>

    <!-- data list -->
    <div class="details">
        <div class="recentLinks">
            <div class="cardHeader">
                <h2>جدیدترین لینک ها</h2>
                <a href="" class="btn">همه لینک ها</a>
            </div>
            <table>
                <thead>
                <tr>
                    <td>عنوان</td>
                    <td>لینک</td>
                    <td>بازدیدها</td>
                    <td>وضعیت</td>
                    <td>تغییرات</td>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><a><?php echo e(Str::limit($url->title, 20)); ?></a></td>
                        <td>
                            <a href="<?php echo e(route('click', [$url->url_code])); ?>">
                                <?php echo e(route('click', [$url->url_code])); ?>

                            </a>
                        </td>
                        <td><?php echo e($url->views); ?></td>

                        <?php if($url->status === 'active'): ?>
                            <td><span class="status active-link">فعال</span></td>
                        <?php elseif($url->status === 'inactive'): ?>
                            <td><span class="status inactive-link">غیر فعال</span></td>
                        <?php elseif($url->status === 'deleted'): ?>
                            <td><span class="status deleted-link">حذف شده</span></td>
                        <?php endif; ?>
                        <td><span class="status inactive-link"><a
                                    href="<?php echo e(route('urls.edit',[$url])); ?>" style="color: #fff">ویرایش</a></span></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eddie/Code/laravel-projects/dotlink/resources/views/dashboard.blade.php ENDPATH**/ ?>