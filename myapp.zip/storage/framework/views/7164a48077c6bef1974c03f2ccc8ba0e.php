<?php echo e($slot); ?>

<?php /**PATH /home/eddie/Code/laravel-projects/dotlink/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>