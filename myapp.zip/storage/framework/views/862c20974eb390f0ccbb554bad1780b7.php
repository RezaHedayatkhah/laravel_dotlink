<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/form.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <form action="" class="form-container" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <?php if(Session::has('status')): ?>
            <div class="alert alert-info" role="alert">
                <?php echo e(Session::get('status')); ?>

            </div>
        <?php endif; ?>
        <!-- title input -->
        <h1>پروفایل</h1>
        <div class="input-container">
            <input type="text" name="first_name" id="first_name" class="form-input" placeholder="نام کوچک"
                   value="<?php echo e(auth()->user()->first_name); ?>"/>
            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="input-container">
            <input type="text" name="last_name" id="last_name" class="form-input"
                   value="<?php echo e(auth()->user()->last_name); ?>"
                   placeholder="نام خانوادگی"/>
            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <?php if(!auth()->user()->hasVerifiedEmail()): ?>
        <div class="input-container">
            <input type="email" name="email" id="email" class="form-input"
                   required value="<?php echo e(auth()->user()->email); ?>"
                   placeholder="ایمیل"/>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <?php else: ?>
        <div class="input-container">
            <input type="email" name="email" id="email" class="form-input"
                   required value="<?php echo e(auth()->user()->email); ?>"
                   placeholder="ایمیل" readonly style="color: gray!important"/>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <?php endif; ?>

        <div class="input-container">
            <input type="text" name="id_code" id="id_code" class="form-input"
                   value="<?php echo e(auth()->user()->id_code); ?>" placeholder="کد ملی"/>
            <?php $__errorArgs = ['id_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="input-container">
            <input type="text" name="phone_number" id="phone_number" class="form-input"
                   value="<?php echo e(auth()->user()->phone_number); ?>"
                   placeholder="شماره موبایل"/>
            <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="input-container">
            <input type="text" name="card_number" id="card_number" class="form-input"
                   value="<?php echo e(auth()->user()->card_number); ?>" placeholder="شماره کارت بانکی"/>
            <?php $__errorArgs = ['card_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Submit button -->
        <button type="submit" class="form-button">ذخیره</button>
    </form>
    <?php if(!auth()->user()->hasVerifiedEmail()): ?>

    <form action="<?php echo e(route('verification.send')); ?>" method="post" style="text-align: center">
        <?php echo csrf_field(); ?>
        <button type="submit" class="form-button" style="background-color: green">
            ارسال تأیید ایمیل
        </button>
    </form>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eddie/Code/laravel-projects/dotlink/resources/views/profile.blade.php ENDPATH**/ ?>