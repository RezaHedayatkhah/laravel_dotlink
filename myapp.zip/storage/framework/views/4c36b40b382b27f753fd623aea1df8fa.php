<?php $__env->startSection('content'); ?>
<div class="container-fluid">


    <div class="d-flex flex-row justify-content-center my-5">
        <div class=" col-12">
            <div class="card card-color text-white">
                <div class="card-header">
                    <h1 class="card-title">ورود</h1>
                </div>
                <div class="card-body d-flex flex-row justify-content-between p-5">
                    <?php if(Session::has('status')): ?>
                    <div class="alert alert-info" role="alert">
                        <?php echo e(Session::get('status')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="d-flex justify-content-start col-8">
                        <img class="w-75" height="400px" src="<?php echo e(asset('images/undraw_sign_up_n6im.svg')); ?>" alt="">
                    </div>
                    <form action="<?php echo e(route('login')); ?>" method="POST" class="col-4">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="email" class="form-label">آدرس ایمیل</label>
                            <input type="email" name="email" class="form-control border-0 bg-dark-subtle" id="email"
                                required>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-4">
                            <label for="password" class="form-label">رمز عبور </label>
                            <input type="password" name="password" class="form-control border-0 bg-dark-subtle"
                                id="password" required>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <div class="d-grid">
                                <button class="btn btn-primary">ورود</button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eddie/Code/laravel-projects/dotlink/resources/views/login.blade.php ENDPATH**/ ?>