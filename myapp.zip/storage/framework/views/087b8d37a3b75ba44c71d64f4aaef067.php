<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/form.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <form class="form-container" action="<?php echo e(route('urls.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if(Session::has('status')): ?>
            <div class="alert" role="alert">
                <?php echo e(Session::get('status')); ?>

            </div>
        <?php endif; ?>
        <h1>لینک جدید</h1>
        <div class="input-container">
            <input id="title" name="title" class="form-input" type="text" placeholder="عنوان"/>
        </div>
        <div class="input-container">
            <input id="long_url" name="long_url" class="form-input" type="text" placeholder="لینک" required/>
        </div>
        <div class="input-container">
            <input id="description" name="description" class="form-input" type="text" placeholder="توضیحات"/>
        </div>
        <button type="submit" class="form-button">کوتاه کن!</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eddie/Code/laravel-projects/dotlink/resources/views/create.blade.php ENDPATH**/ ?>