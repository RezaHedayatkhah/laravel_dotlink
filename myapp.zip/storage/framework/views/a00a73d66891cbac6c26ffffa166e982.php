<?php $__env->startSection('content'); ?>

    <!-- data list -->
    <div class="details">
        <div class="recentLinks">
            <div class="cardHeader">
                <h2>لینک ها</h2>
            </div>
            <table>
                <thead>
                <tr>
                    <td>عنوان</td>
                    <td>لینک کوتاه</td>
                    <td>بازدیدها</td>
                    <td>وضعیت</td>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><a href="<?php echo e(route('urls.edit',[$url])); ?>"><?php echo e(Str::limit($url->title, 20)); ?></a></td>
                        <td>
                            <a href="<?php echo e(route('click', [$url->url_code])); ?>">
                                <?php echo e(route('click', [$url->url_code])); ?>

                            </a>
                        </td>
                        <td><?php echo e($url->views); ?></td>

                        <?php if($url->status === 'active'): ?>
                            <td><span class="status active-link">فعال</span></td>
                        <?php elseif($url->status === 'inactive'): ?>
                            <td><span class="status inactive-link">غیر فعال</span></td>
                        <?php elseif($url->status === 'deleted'): ?>
                            <td><span class="status deleted-link">حذف شده</span></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eddie/Code/laravel-projects/dotlink/resources/views/index.blade.php ENDPATH**/ ?>