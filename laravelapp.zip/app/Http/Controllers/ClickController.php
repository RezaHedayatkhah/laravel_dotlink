<?php

namespace App\Http\Controllers;

use App\Models\Url;
use App\Models\visitorIP;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class ClickController extends Controller
{
    public function click(Request $request, string $url_code)
    {
        if ($url = Url::where('url_code', $url_code)->first()) {
            if ($visitor = visitorIP::where('ip',  $request->getClientIp())->first()) {
                if (Carbon::parse($visitor->last_login_at)->diffInHours(Carbon::now()) > 24) {
                    $visitor->last_login_at = Carbon::now()->toDateTimeString();
                    if ($visitor->save()) {
                        $url->increment('views');
                        $url->save();
                    }
                }
            } else {
                $visitor = new visitorIP();
                $visitor->ip = $request->getClientIp();
                $visitor->last_login_at = Carbon::now()->toDateTimeString();
                if ($visitor->save()) {
                    $url->increment('views');
                    $url->save();
                }
            }
        }
        return Redirect::away($url->long_url);
    }
}
