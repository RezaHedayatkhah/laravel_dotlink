<?php $__env->startSection('content'); ?>
<div class="container card-color shadow rounded text-white px-4 py-3">
    <?php if(session('status')): ?>
        <div class="alert alert-success mb-1 mt-1">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
    <form action="<?php echo e(route('urls.update', $url->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <!-- title input -->
        <div class="form-outline mb-4">
            <label class="form-label" for="form4Example1">عنوان</label>
          <input type="text" name="title" id="form4Example1" class="form-control border-0 text-white" style="background-color: #383838;" placeholder="عنوان لینک..." value="<?php echo e($url->title); ?>"/>
          <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- link input -->
        <div class="form-outline mb-4">
            <label class="form-label" for="form4Example2">لینک</label>
          <input type="url" name="long_url" id="form4Example2" class="form-control border-0 text-white" style="background-color: #383838;" placeholder="لینک را اینجا وارد کنید" required value="<?php echo e($url->long_url); ?>"/>
          <?php $__errorArgs = ['long_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- description input -->
        <div class="form-outline mb-4">
            <label class="form-label" for="form4Example3">توضیحات</label>
          <textarea class="form-control border-0 text-white" name="description" id="form4Example3" style="background-color: #383838;" rows="4" placeholder="توضیحات لینک"><?php echo e($url->description); ?></textarea>
          <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Submit button -->
        <button type="submit" class="btn btn-primary btn-block mb-4">ثبت تغییرات</button>
      </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eddie/Code/laravel-projects/dotlink/resources/views/edit.blade.php ENDPATH**/ ?>