<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-center align-items-center vh-100 ">
<h1 class="fs-1 text-info">بزودی</h1>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eddie/Code/laravel-projects/dotlink/resources/views/settings.blade.php ENDPATH**/ ?>